# **React Native FlatList demo with Typescript**

A RN demo with a FlatList component showing a list of students.

The Redux code is organised using the [ducks pattern](https://github.com/erikras/ducks-modular-redux).

To run the project, please type: -

i) cd into the project directory.

ii) type in `npm i -g react-native-cli` && then `npm i`.

iii) type in `npm run watch`.

iv) open another terminal window and cd into the project directory and then type `react-native run-ios`.
