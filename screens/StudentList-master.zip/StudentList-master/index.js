import { AppRegistry } from 'react-native';
import App from './out/App';

AppRegistry.registerComponent('StudentList', () => App);
